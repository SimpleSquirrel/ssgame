package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;

public class Assets {

    public static Texture textureMenuScreenBack;
    public static Sprite spriteMenuScreenBack;
    public static Texture textureNewGameButtonActive;
    public static Texture textureContinueGameButtonActive;
    public static Texture texturePreferencesButtonActive;
    public static Texture textureExitButtonActive;
    public static Sprite spriteNewGameButtonActive;
    public static Sprite spriteContinueGameButtonActive;
    public static Sprite spritePreferencesButtonActive;
    public static Sprite spriteExitButtonActive;
    public static Texture textureNewGameButtonInactive;
    public static Texture textureContinueGameButtonInactive;
    public static Texture texturePreferencesButtonInactive;
    public static Texture textureExitButtonInactive;
    public static Sprite spriteNewGameButtonInactive;
    public static Sprite spriteContinueGameButtonInactive;
    public static Sprite spritePreferencesButtonInactive;
    public static Sprite spriteExitButtonInactive;



    public static void load() {
        textureMenuScreenBack = new Texture(Gdx.files.internal("MenuScreen/Back.jpg"));
        textureMenuScreenBack.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        spriteMenuScreenBack = new Sprite(textureMenuScreenBack);
        spriteMenuScreenBack.flip(false, true);
        textureNewGameButtonActive = new Texture(Gdx.files.internal("MenuScreen/NewGame.png"));
        textureNewGameButtonActive.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        spriteNewGameButtonActive = new Sprite(textureNewGameButtonActive);
        textureContinueGameButtonActive = new Texture(Gdx.files.internal("MenuScreen/ContinueGame.png"));
        textureContinueGameButtonActive.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        spriteContinueGameButtonActive = new Sprite(textureContinueGameButtonActive);
        texturePreferencesButtonActive = new Texture(Gdx.files.internal("MenuScreen/Preferences.png"));
        texturePreferencesButtonActive.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        spritePreferencesButtonActive = new Sprite(texturePreferencesButtonActive);
        textureExitButtonActive = new Texture(Gdx.files.internal("MenuScreen/Exit.png"));
        textureExitButtonActive.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        spriteExitButtonActive = new Sprite(textureExitButtonActive);
        textureNewGameButtonInactive = new Texture(Gdx.files.internal("MenuScreen/NewGame0.png"));
        textureNewGameButtonInactive.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        spriteNewGameButtonInactive = new Sprite(textureNewGameButtonInactive);
        textureContinueGameButtonInactive = new Texture(Gdx.files.internal("MenuScreen/ContinueGame0.png"));
        textureContinueGameButtonInactive.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        spriteContinueGameButtonInactive = new Sprite(textureContinueGameButtonInactive);
        texturePreferencesButtonInactive = new Texture(Gdx.files.internal("MenuScreen/Preferences0.png"));
        texturePreferencesButtonInactive.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        spritePreferencesButtonInactive = new Sprite(texturePreferencesButtonInactive);
        textureExitButtonInactive = new Texture(Gdx.files.internal("MenuScreen/Exit0.png"));
        textureExitButtonInactive.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        spriteExitButtonInactive = new Sprite(textureExitButtonInactive);
    }
}